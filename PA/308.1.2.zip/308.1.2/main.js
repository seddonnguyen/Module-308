
let width = 12;
let height = 10;

function upsideDownTrapezoid(width, height) {
  if(width < 2* height ){
    console.log("Impossible Shape!");
    return;
  }
  for (let h = 0; h < height; h++) {
    let str = "";
    for (let space = 0; space < h; space++) {
      str += " ";
    }
    for (let star = 0; star < (width - h * 2); star++) {
      str += "*";
    }
    console.log(str);
  }
}

//upsideDownTrapezoid(width, height);

function printCross(size) {
  for(let row = 0; row < size; row++) {
    let str = "";
    for(let col = 0; col < size; col++) {

      if(row == col || col == size - 1 - row) {
        str += "*";
      } else {
        str += " ";
      }
    }
    console.log(str);
  }
}

printCross(9);