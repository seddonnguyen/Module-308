const data = [
    { id: 1, name: "Nike", model: "VaporMax", trim: "unisex", img: "../images/nike.jpeg" },
    { id: 2, name: "Adidas", model: "Samba", trim: "unisex", img: "../images/adidas.avif" },
    { id: 3, name: "Vans", model: "Old Skool", trim: "unisex", img: "../images/vans.webp" },
    { id: 4, name: "Converse", model: "Chuck Taylor", trim: "unisex", img: "../images/converse.webp" },
    { id: 5, name: "Reebok", model: "C 85 Vintage", trim: "unisex", img: "../images/reebok.webp" },
    
    { id: 6, name: "New balance", model: "806", trim: "womens", img: "../images/newbalance.jpg" },
    { id: 7, name: "HOKA", model: "Samba", trim: "Mens", img: "../images/hoka.jpeg" },
    { id: 8, name: "Coach", model: "Wiley Pump", trim: "Outlet", img: "../images/coach.webp" },
    { id: 9, name: "New Balance", model: "327", trim: "womens", img: "../images/newbalance2.webp" },
    { id: 10, name: "Cavalier", model: "C 85 Vintage", trim: "womens", img: "../images/reebok.webp" },

    { id: 11, name: "Brooks", model: "Glycerin 20", trim: "womens", img: "../images/brooksrunning.avif" },
    { id: 12, name: "Oxford", model: "FLORSHEIM ", trim: "mens", img: "../images/grainger.jpeg" },
    { id: 13, name: "Mule", model: "Mule1", trim: "Sport", img: "../images/pexels.webp" },
    { id: 14, name: "LV Sandals", model: "Rivage Sandal", trim: "womens", img: "../images/lv.avif" },
    { id: 15, name: "Sneakers", model: "Sneakers1", trim: "Pro", img: "../images/sneakers.jpg" },
  ];
  
  export default data;