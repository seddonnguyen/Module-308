const data = [
  {
    id: 1,
    make: "Ferrari",
    img: "../images/cars.jpg",
  },
  {
    id: 2,
    make: "Nissan",
    img: "../images/cars2.jpg",
  },
  {
    id: 3,
    make: "Audi",
    img: "../images/cars3.jpg",
  },
  {
    id: 4,
    make: "Lamborghini",
    img: "../images/cars4.jpg",
  },
  {
    id: 5,
    make: "Tesla",
    img: "../images/cars5.jpg",
  },
  {
    id: 6,
    make: "Mercedes-Benz",
    img: "../images/cars6.jpg",
  },
  {
    id: 7,
    make: "Dodge",
    img: "../images/cars7.jpg",
  },
  {
    id: 8,
    make: "Bmw",
    img: "../images/cars8.jpg",
  },
];

export default data;
