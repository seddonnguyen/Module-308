const data = [
  { id: 1, make: "Toyota", model: "Tacoma", trim: "SE", img: "../images/tacoma-se-2023.jpg" },
  { id: 2, make: "Toyota", model: "Tacoma", trim: "SR", img: "../images/tacoma-sr-2023.webp" },
  { id: 3, make: "Toyota", model: "Tacoma", trim: "Sport", img: "../images/TRD-sport-2023.png" },
  { id: 4, make: "Toyota", model: "Tacoma", trim: "Off-Road", img: "../images/TRD-off-road-2023.jpg" },
  { id: 5, make: "Toyota", model: "Tacoma", trim: "Pro", img: "../images/TRD-Pro-2023.jpg" },
];

export default data;
